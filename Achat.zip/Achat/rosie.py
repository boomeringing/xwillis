import aiml
import uuid
import datetime
import os
import hashlib
import json

MEMORY_FILE = "aiml_memory.json"

class AIMLBot:
    def __init__(self, name="AIMLUnit", brain_file="config.aiml"):
        self.name = name
        self.uuid = str(uuid.uuid4())
        self.kernel = aiml.Kernel()
        self.log = []
        self.boot_time = datetime.datetime.now()

        if os.path.exists(brain_file):
            print(f"[aiml] Loading brain: {brain_file}")
            self.kernel.learn(brain_file)
        else:
            print(f"[aiml] Warning: AIML file '{brain_file}' not found.")

        self.memory = self.load_memory()

    def load_memory(self):
        if os.path.exists(MEMORY_FILE):
            try:
                with open(MEMORY_FILE, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                print("[aiml] Corrupted memory. Starting fresh.")
        return {"id": self.uuid, "log": []}

    def save_memory(self):
        with open(MEMORY_FILE, 'w') as f:
            json.dump(self.memory, f, indent=2)

    def listen(self, text):
        ts = datetime.datetime.now().isoformat()
        log_entry = {"in": text, "time": ts}
        response = self.kernel.respond(text)
        if not response:
            response = f"[Unrecognized input] Hash: {hashlib.sha256(text.encode()).hexdigest()[:10]}"
        log_entry["out"] = response
        self.memory["log"].append(log_entry)
        self.save_memory()
        return response

    def shutdown(self):
        print(f"[aiml] Shutting down. Uptime: {datetime.datetime.now() - self.boot_time}")

if __name__ == '__main__':
    bot = AIMLBot()
    print("[aiml] Ready to chat. Type 'exit' to quit.")
    try:
        while True:
            user_input = input("You> ")
            if user_input.lower() in ['exit', 'quit']:
                break
            reply = bot.listen(user_input)
            print(f"Bot> {reply}")
    except KeyboardInterrupt:
        pass
    finally:
        bot.shutdown()
